import React, { Component } from "react";
import axios from "axios";
import "../App";

const url = "http://localhost:2040/allocate/";

class AllocateSolar extends Component {
  constructor(props) {
    super(props);
    this.state = {
      formValue: {
        distributorName: "",
        purchaseDate: "",
        installationDate: "",
        customerName: "",
        customerLocation: ""
      },
      formErrorMessage: {
        distributorName: "",
        purchaseDate: "",
        installationDate: "",
        customerName: "",
        customerLocation: ""
      },
      formValid: {
        distributorName: false,
        purchaseDate: false,
        installationDate: false,
        customerName: false,
        customerLocation: false,
        buttonActive: false
      },
      successMessage: "",
      errorMessage: ""
    }
  }

  submitAllocation = () => {
    const { formValue } = this.state;
    this.setState({ errorMessage: "", successMessage: "" })
    axios.put(url + formValue.distributorName, formValue)
      .then(response => {
        this.setState({ successMessage: response.data.message, errorMessage: "" });
      }).catch(error => {
        if (error.response) {
          this.setState({ errorMessage: error.response.data.message, successMessage: "" });
        } else {
          this.setState({ errorMessage: "server errror", successMessage: "" });
        }
      });
  }

  handleSubmit = (event) => {
    event.preventDefault();
    this.submitAllocation();
  }

  handleChange = (event) => {
    const target = event.target;
    const value = target.value;
    const name = target.name;
    const { formValue } = this.state;
    this.setState({
      formValue: { ...formValue, [name]: value }
    });
    this.validateField(name, value);
  }

  validateField = (fieldName, value) => {
    let fieldValidationErrors = this.state.formErrorMessage;
    let formValid = this.state.formValid;

    switch (fieldName) {
      case "distributorName":
        formValid.distributorName = (value !== "");
        fieldValidationErrors.distributorName = formValid.distributorName
          ? ""
          : "Please select distributor name";
        break;
      case "customerName":
        const nameRegex = /^[A-z][A-z\s]{3,}$/;
        if (value === "") {
          fieldValidationErrors.customerName = "field required";
          formValid.customerName = false;
        } else if (!value.match(nameRegex)) {
          fieldValidationErrors.customerName = "Please enter valid Name";
          formValid.customerName = false;
        } else {
          fieldValidationErrors.customerName = "";
          formValid.customerName = true;
        }
        break;
      case "customerLocation":
        const locationRegex = /^[A-z][A-z\s]{2,}$/;
        if (value === "") {
          fieldValidationErrors.customerLocation = "field required";
          formValid.customerLocation = false;
        } else if (!value.match(locationRegex)) {
          fieldValidationErrors.customerLocation = "Please enter valid Location";
          formValid.customerLocation = false;
        } else {
          fieldValidationErrors.customerLocation = "";
          formValid.customerLocation = true;
        }
        break;
      case "purchaseDate":
        if (value === "") {
          fieldValidationErrors.purchaseDate = "field required"
          formValid.purchaseDate = false;
        } else {
          let pdate = new Date(value);
          let today = new Date();
          if (pdate < today) {
            fieldValidationErrors.purchaseDate = "Purchase date should be today or greater than todays date";
            formValid.purchaseDate = false;
          } else {
            fieldValidationErrors.purchaseDate = "";
            formValid.purchaseDate = true;
          }
        }
        break;
      case "installationDate":
        if (value === "") {
          fieldValidationErrors.installationDate = "field required"
          formValid.installationDate = false;
        } else {
          let idate = new Date(value);
          let pDate = new Date(this.state.formValue.purchaseDate);
          if (!(idate > pDate && idate < pDate.setDate(pDate.getDate() + 7))) {
            fieldValidationErrors.installationDate = "Installation date should be after purchase date and within 7 days from purchase date";
            formValid.installationDate = false;
          } else {
            fieldValidationErrors.installationDate = "";
            formValid.installationDate = true;
          }
        }
        break;
      default:
        break;
    }
    formValid.buttonActive =
      formValid.customerName &&
      formValid.customerLocation &&
      formValid.distributorName &&
      formValid.installationDate &&
      formValid.purchaseDate
    this.setState({
      formErrorMessage: fieldValidationErrors,
      formValid: formValid,
      successMessage: "", errorMessage: ""
    });
  }

  render() {
    const { distributorName, purchaseDate, installationDate, customerName, customerLocation } = this.state.formValue;
    return (
      <React.Fragment>
        <div className="CreateBooking ">
          <div className="container-fluid row">
            <div className="col-md-6 offset-md-3">
              <br />
              <div className="card">
                <div className="card-header bg-custom">
                  <h4>Allocation Form</h4>
                </div>
                <div className="card-body">
                  <form className="form" onSubmit={this.handleSubmit}>
                    <div className="form-group">
                      <label htmlFor="distributorName">Distributor Name</label>
                      <select
                        name="distributorName"
                        id="distributorName"
                        value={distributorName}
                        onChange={this.handleChange}
                        className="form-control"
                        placeholder="Select a distributor name"
                      >
                        <option value="">--Select a Distributor--</option>
                        <option value="Suntek">Suntek</option>
                        <option value="SupremeSolar">SupremeSolar</option>
                        <option value="A4Solar">A4Solar</option>
                      </select>
                      <span name="distributorNameError" className="text-danger">
                        {this.state.formErrorMessage.distributorName}
                      </span>
                    </div>

                    <div className="form-group">
                      <label htmlFor="customerName">Customer Name</label>
                      <input
                        type="text"
                        placeholder="Enter Customer Name"
                        name="customerName"
                        id="customerName"
                        value={customerName}
                        onChange={this.handleChange}
                        className="form-control"
                      />
                      <span name="customerNameError" className="text-danger">
                        {this.state.formErrorMessage.customerName}
                      </span>
                    </div>

                    <div className="form-group">
                      <label htmlFor="customerLocation">Customer Location</label>
                      <input
                        type="text"
                        placeholder="Enter Customer Location"
                        name="customerLocation"
                        id="customerLocation"
                        value={customerLocation}
                        onChange={this.handleChange}
                        className="form-control"
                      />
                      <span name="customerLocationError" className="text-danger">
                        {this.state.formErrorMessage.customerLocation}
                      </span>
                    </div>

                    <div className="form-group">
                      <label htmlFor="purchaseDate">Purchase Date</label>
                      <input
                        type="date"
                        name="purchaseDate"
                        id="purchaseDate"
                        value={purchaseDate}
                        onChange={this.handleChange}
                        className="form-control"
                      />
                      <span name="purchaseDateError" className="text-danger">
                        {this.state.formErrorMessage.purchaseDate}
                      </span>
                    </div>

                    <div className="form-group">
                      <label>Installation Date</label>
                      <input
                        type="date"
                        name="installationDate"
                        value={installationDate}
                        onChange={this.handleChange}
                        className="form-control"
                      />
                      <span name="installationDateError" className="text-danger">
                        {this.state.formErrorMessage.installationDate}
                      </span>
                    </div>
                    <button type="submit" name="allocateSolar" className="btn btn-primary" disabled={!this.state.formValid.buttonActive}>
                      Allocate Solar
                    </button>
                  </form>
                </div>
                <span name="successMessage" className="text-success font-weight-bold message">
                  {this.state.successMessage}
                </span>
                <span name="errorMessage" className="text-danger font-weight-bold message">
                  {this.state.errorMessage}
                </span>
              </div>
            </div>
          </div>
        </div>
      </React.Fragment>
    );
  }
}

export default AllocateSolar;