import React, { Component } from "react";
import axios from "axios";
import "../App.css";

const url = "http://localhost:2040/findService/";

class GetDistributors extends Component {
  constructor(props) {
    super(props);
    this.state = {
      distributorData: [],
      form: {
        customerLocation: ""
      },
      formErrorMessage: {
        customerLocation: ""
      },
      formValid: {
        customerLocation: false,
        buttonActive: false
      },
      errorMessage: "",
      successMessage: ""
    };
  }

  handleSubmit = (event) => {
    event.preventDefault();
    this.fetchDistributorByLocation();
  }

  handleChange = (event) => {
    const target = event.target;
    const value = target.value;
    const name = target.name;
    const { form } = this.state;
    this.setState({
      form: { ...form, [name]: value }
    });
    this.validateField(name, value);
  }

  validateField = (fieldName, value) => {
    let fieldValidationErrors = this.state.formErrorMessage;
    let formValid = this.state.formValid;

    switch (fieldName) {
      case "customerLocation":
        const locationRegex = /^[A-z][A-z\s]{2,}$/;
        if (value === "") {
          fieldValidationErrors.customerLocation = "field required";
          formValid.customerLocation = false;
        } else if (!value.match(locationRegex)) {
          fieldValidationErrors.customerLocation = "Please enter valid Location";
          formValid.customerLocation = false;
        } else {
          fieldValidationErrors.customerLocation = "";
          formValid.customerLocation = true;
        }
        break;
      default:
        break;
    }
    formValid.buttonActive = formValid.customerLocation
    this.setState({
      formErrorMessage: fieldValidationErrors,
      formValid: formValid,
      distributorData: null, errorMessage:""
    });
  }

  fetchDistributorByLocation = () => {
    this.setState({ distributorData: null, errorMessage: "" })
    axios.get(url + this.state.form.customerLocation).then(response => {
      this.setState({ distributorData: response.data, errorMessage: "" });
    }).catch(error => {
      if (error.response) {
        this.setState({ distributorData: null, errorMessage: error.response.data.message })
      } else {
        this.setState({ distributorData: null, errorMessage: "Server Error" });
      }
    });
  }

  render() {
    return (
      <React.Fragment>
        <div className="row">
          <div className="col-md-6 offset-md-3">
            <br />
            <div className="card">
              <div className="card-header bg-custom text-center">
                <h4>View Distributors</h4>
              </div>
              <div className="card-body view">
                <form className="form" onSubmit={this.handleSubmit}>
                  <div className="form-group">
                    <label htmlFor="customerLocation">Customer Location</label>
                    <input className="form-control" id="customerLocation" name="customerLocation" value={this.state.form.customerLocation} onChange={this.handleChange} />
                    <span name="customerLocationError" className="text-danger">{this.state.formErrorMessage.customerLocation}</span>
                  </div>
                  <button type="submit" name="getDistributors" className="btn btn-primary" disabled={!this.state.formValid.buttonActive}>Get Distributors</button>
                </form>
                <br />
                {
                  this.state.distributorData ?
                    <div className="text-success" name="successMessage">
                      <h3>The Distributors available in {this.state.form.customerLocation} are:</h3>
                      <ul>
                        {this.state.distributorData.map(allocation => <li key={allocation}><h5>{allocation}</h5></li>)}
                      </ul>
                    </div>
                    : <span name="errorMessage" className="text-danger">{this.state.errorMessage}</span>
                }
              </div>
            </div>
          </div>
        </div>
      </React.Fragment>
    );
  }
}

export default GetDistributors;