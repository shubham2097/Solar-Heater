import React from "react";
import { shallow, mount } from "enzyme";
import AllocateSolar from "./components/AllocateSolar";
import GetDistributors from "./components/GetDistributors";
import MockAdapter from "axios-mock-adapter";

// -------------------------- structural test cases----------------------------------
describe("AllocateSolar COMPONENT", () => {

  test("CBJT1-AllocateSolar component has a form", () => {
    const wrapper = shallow(<AllocateSolar />);
    expect(wrapper.find("form")).toHaveLength(1);
  });

  test("CBJT2-AllocateSolar component has five fields (4 inputs and 1 dropdown)", () => {
    const wrapper = shallow(<AllocateSolar />);
    expect(wrapper.find("form").find("input").length + wrapper.find("form").find("select").length).toEqual(5);
  });

  test("CBJT3-AllocateSolar component has a button with name allocateSolar", () => {
    const wrapper = shallow(<AllocateSolar />);
    expect(wrapper.find("form").find('button[name="allocateSolar"]')).toHaveLength(1);
  });

  test("CBJT4-AllocateSolar component has a dropdown", () => {
    const wrapper = shallow(<AllocateSolar />);
    expect(wrapper.find("form").find("select")).toHaveLength(1);
  });

  test("CBJT5-Name prop of all the input fields is proper", () => {
    const wrapper = shallow(<AllocateSolar />);
    let status = false;
    if (wrapper.find("form").find("select").at(0).props().name == "distributorName" &&
      wrapper.find("form").find("input").at(0).props().name == "customerName" &&
      wrapper.find("form").find("input").at(1).props().name == "customerLocation" &&
      wrapper.find("form").find("input").at(2).props().name == "purchaseDate" &&
      wrapper.find("form").find("input").at(3).props().name == "installationDate") { status = true; }
    expect(status).toEqual(true);
  });

  test("CBJT6-tags for displaying error message of all the fields of AllocateSolar Component has appropriate name", () => {
    const wrapper = shallow(<AllocateSolar />);
    let distributorNameError = wrapper.find('[name="distributorNameError"]').length;
    let customerNameError = wrapper.find('[name="customerNameError"]').length;
    let customerLocationError = wrapper.find('[name="customerLocationError"]').length;
    let purchaseDateError = wrapper.find('[name="purchaseDateError"]').length;
    let installationDateError = wrapper.find('[name="installationDateError"]').length;
    expect(distributorNameError + customerLocationError + customerNameError + purchaseDateError + installationDateError).toEqual(5);
  });

  test("CBJT7-form level success and error message of AllocateSolar Component has appropriate name", () => {
    const wrapper = shallow(<AllocateSolar />);
    let successMessage = wrapper.find('[name="successMessage"]').length;
    let errorMessage = wrapper.find('[name="errorMessage"]').length;
    expect(errorMessage + successMessage).toEqual(2);
  });

  test("CBJT8-All the input fields have formcontrol class", () => {
    const wrapper = shallow(<AllocateSolar />);
    let customerName = wrapper.find('input[name="customerName"]').hasClass('form-control');
    let distributorName = wrapper.find('select[name="distributorName"]').hasClass('form-control');
    let purchaseDate = wrapper.find('input[name="purchaseDate"]').hasClass('form-control');
    let installationDate = wrapper.find('input[name="installationDate"]').hasClass('form-control');
    let customerLocation = wrapper.find('input[name="customerLocation"]').hasClass('form-control');
    expect(installationDate && purchaseDate && distributorName && customerName && customerLocation).toEqual(true);
  });
})

describe("GetDistributors Component", () => {
  test("CBJT9-GetDistributors component has a form", () => {
    const wrapper = shallow(<GetDistributors />);
    expect(wrapper.find("form")).toHaveLength(1);
  });

  test("CBJT10-GetDistributors component has one input field with name customerLocation", () => {
    const wrapper = shallow(<GetDistributors />);
    expect(wrapper.find("form").find('input[name="customerLocation"]').length).toEqual(1);
  });

  test("CBJT11-GetDistributors component has a button with name getDistributors", () => {
    const wrapper = shallow(<GetDistributors />);
    expect(wrapper.find("form").find('button[name="getDistributors"]')).toHaveLength(1);
  });

  test("CBJT12-All error message tags of GetDistributors component have appropriate name", () => {
    const wrapper = shallow(<GetDistributors />);
    wrapper.setState({ distributorData: false });
    let customerLocationError = wrapper.find('[name="customerLocationError"]').length;
    let errorMessage = wrapper.find('[name="errorMessage"]').length;
    // let successMessage = wrapper.find('[name="successMessage"]').length;
    // console.log(customerLocationError + errorMessage + successMessage);
    expect(customerLocationError + errorMessage).toEqual(2);
  });

  // test("CBJT13-All success data displayed in GetDistributors component has appropriate name", () => {
  //   const wrapper = shallow(<GetDistributors />);
  //   // wrapper.state().allocationData = [10, 20];
  //   wrapper.setState({ distributorData: true });
  //   let successMessage = wrapper.find('ul').length;
  //   expect(successMessage).toEqual(1);
  // });

  test("CBJT13-formcontrol class is appropriately used ", () => {
    const wrapper = shallow(<GetDistributors />);
    expect(wrapper.find("form").find('input').hasClass('form-control')).toEqual(true);
  });
})